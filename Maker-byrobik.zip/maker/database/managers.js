const mongoose = require("mongoose")
const {client , guildid} = require("../index")
const { WebhookClient , EmbedBuilder} = require('discord.js')
const {token , owner , database} = require('../config.json')

let Schema = new mongoose.Schema({
    guildid:{
        type:String,
        default:guildid
    },
    id:{
        type:String,
    },
    points:{
        type:String,
        default:0,
    },
});
module.exports = mongoose.model('manager' , Schema)