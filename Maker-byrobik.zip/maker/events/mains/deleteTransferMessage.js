const { Client, Collection,ActivityType, discord,GatewayIntentBits, Partials , EmbedBuilder, ApplicationCommandOptionType , Events , ActionRowBuilder , ButtonBuilder ,MessageAttachment, ButtonStyle , Message } = require("discord.js");
let {mainguild} = require('../../config.json')
const { Database } = require("st.db")
const ms = require("ms")
const cooldown = new Collection()
const setting = new Database("/database/settingsdata/setting")
const {token , owner , database} = require('../../config.json')

module.exports = {
	name: Events.MessageCreate,
	execute: async(message) => {
        let client = message.client
        const transfer_room = setting.get(`transfer_room_${message.guild.id}`)
        const probot = setting.get(`probot_${message.guild.id}`)
        if(!probot && !transfer_room) return;
        if(message.author.id == probot) return;
        if(message.channel.id != transfer_room) return;
        if(message.author.id == client.user.id) return;
        setTimeout(() => {
            try {
                message.delete().catch(async() => {return;})
            } catch (error) {
                return
            }
        }, 15000);
  }};
