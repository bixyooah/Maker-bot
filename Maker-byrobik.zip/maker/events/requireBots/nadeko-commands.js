const fs = require('fs');
const ascii = require('ascii-table');
let table = new ascii(`commands`);
table.setHeading('Command', 'Commands Status💹')
const path = require('path');
const {token , owner , database} = require('../../config.json')

const { WebhookClient , EmbedBuilder} = require('discord.js')
module.exports = (client15) => {
    const commandsDir = path.join(__dirname, '../../Bots/nadeko/commands15');
    if(!fs.existsSync(commandsDir)) return;
fs.readdirSync(commandsDir).forEach(async(folder) => {
    const folderPath = path.join(commandsDir, folder);
        const commandFiles = fs.readdirSync(folderPath).filter(file => file.endsWith('.js'));
        for(file of commandFiles) {
            const filePath = path.join(folderPath, file);
            let commands = require(filePath)
            if(commands.name) {
                client15.commands.set(commands.name, commands);

            }else{
                continue;
            }
        }
    });
}