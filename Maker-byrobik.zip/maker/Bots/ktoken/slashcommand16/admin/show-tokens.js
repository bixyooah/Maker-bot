const { SlashCommandBuilder } = require('discord.js');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('show-tokens')
        .setDescription('اظهار جميع الأعضاء الوهمية في السرفر'),
    async execute(interaction) {
        const members = await interaction.guild.members.fetch();
        const mentionedUsers = members.filter(member => /\d{4}$/.test(member.user.username)).map(member => member.toString()).join(', ');

        let replyMessage = mentionedUsers ? `** التوكنات:**\n${mentionedUsers}` : '**لا يوجد توكنات بهذا السرفر**';

        interaction.reply(replyMessage);
    }
};
