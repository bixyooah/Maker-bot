const { SlashCommandBuilder } = require('discord.js');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('count-tokens')
        .setDescription('حساب عدد الأعضاء الوهمية'),
    async execute(interaction) {
        const members = await interaction.guild.members.fetch();
        let count = 0;
        members.forEach(member => {
            const username = member.user.username;
            if (/\d{4}$/.test(username)) {
                count++;
            }
        });

        interaction.reply(`عدد الأعضاء الوهمية هو: ${count}`);
    }
};
