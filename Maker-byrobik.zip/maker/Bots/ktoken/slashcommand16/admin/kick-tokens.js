const { SlashCommandBuilder, PermissionsBitField } = require('discord.js');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('kick-tokens')
        .setDescription('طرد الأعضاء الوهميين من السرفر'),
    async execute(interaction) {
        if (!interaction.member.permissions.has(PermissionsBitField.Flags.KickMembers)) {
            return interaction.reply('ليس لديك الصلاحية لطرد الأعضاء.');
        }

        const botMember = await interaction.guild.members.fetch(interaction.client.user.id);
        if (!botMember.permissions.has(PermissionsBitField.Flags.KickMembers)) {
            return interaction.reply('ليس لدي الصلاحية لطرد الأعضاء.');
        }

        await interaction.reply('جاري طرد التوكنات...');

        const members = await interaction.guild.members.fetch();
        let kickedCount = 0;
        const promises = [];

        members.forEach(member => {
            const username = member.user.username;
            if (/\d{4}$/.test(username)) {
                if (member.kickable) {
                    promises.push(
                        member.kick()
                            .then(() => {
                                kickedCount++;
                            })
                            .catch(console.error)
                    );
                }
            }
        });

        await Promise.all(promises);

        interaction.followUp(`تم طرد ${kickedCount} من التوكنات من السرفر.`);
    }
};
