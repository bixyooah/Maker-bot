const { Interaction, EmbedBuilder } = require('discord.js');
const { tokens } = require('../../../tokens/tokens');

module.exports = {
    name: 'tax_button',
    async execute(interaction) {
        try {
            let tax = tokens.get('tax');
            if (!tax) return interaction.reply({ content: 'Tax information not available.', ephemeral: true });

            const number = interaction.options.getNumber('number');

            let calculatedTax = Math.floor(number * 20 / 19 + 1);

            let embed = new EmbedBuilder()
                .setTitle('Tax Information')
                .setDescription(`Tax calculated for ${number}: ${calculatedTax}`)
                .setColor('#ffd700');

            await interaction.reply({ embeds: [embed] });
        } catch (error) {
            console.error(error);
            await interaction.reply({ content: 'An error occurred while processing your request.', ephemeral: true });
        }
    },
};
