const { Interaction, EmbedBuilder } = require('discord.js');

module.exports = {
    name: 'total_button',
    async execute(interaction) {
        try {
            const number = interaction.options.getNumber('number');

            // Calculate total with intermediary fee logic here
            let totalWithIntermediaryFee = Math.floor(number * 20 / 19 + 1);

            let embed = new EmbedBuilder()
                .setTitle('Total with Fee Information')
                .setDescription(`Total with fee calculated for ${number}: ${totalWithIntermediaryFee}`)
                .setColor('#808080');

            await interaction.reply({ embeds: [embed] });
        } catch (error) {
            console.error(error);
            await interaction.reply({ content: 'An error occurred while processing your request.', ephemeral: true });
        }
    },
};
